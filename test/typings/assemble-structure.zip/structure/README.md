assemble-blog-template
======================

An example template for creating a blog with Assemble. By @andismith
