/// <reference path="../Interfaces.d.ts" />
export declare function emitPropRefHint(bindingName: string, bindingString: string): void;
