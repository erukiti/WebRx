/// <reference path="Interfaces.d.ts" />
export declare function install(): void;
