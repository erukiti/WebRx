export const version = '1.3.0';
//# sourceMappingURL=Version.js.map