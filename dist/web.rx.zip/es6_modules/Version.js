export const version = '1.2.1';
//# sourceMappingURL=Version.js.map