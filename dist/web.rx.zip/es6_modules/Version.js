export const version = '1.1.1';
//# sourceMappingURL=Version.js.map