export const version = '1.3.1';
//# sourceMappingURL=Version.js.map