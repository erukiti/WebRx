export const version = '1.4.3';
//# sourceMappingURL=Version.js.map