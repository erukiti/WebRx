export const version = '1.0.0';
//# sourceMappingURL=Version.js.map