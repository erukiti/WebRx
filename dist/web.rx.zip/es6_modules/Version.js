export const version = '0.9.88';
//# sourceMappingURL=Version.js.map