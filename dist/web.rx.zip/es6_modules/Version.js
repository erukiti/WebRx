export const version = '1.4.1';
//# sourceMappingURL=Version.js.map