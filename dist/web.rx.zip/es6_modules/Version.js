export const version = '0.9.87';
//# sourceMappingURL=Version.js.map