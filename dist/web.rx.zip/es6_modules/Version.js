export const version = '1.3.2';
//# sourceMappingURL=Version.js.map