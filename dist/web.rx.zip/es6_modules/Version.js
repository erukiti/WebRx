export const version = '0.9.78';
//# sourceMappingURL=Version.js.map