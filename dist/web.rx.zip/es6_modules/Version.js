export const version = '1.0.1';
//# sourceMappingURL=Version.js.map