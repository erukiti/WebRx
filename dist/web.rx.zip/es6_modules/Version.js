export const version = '1.1.0';
//# sourceMappingURL=Version.js.map