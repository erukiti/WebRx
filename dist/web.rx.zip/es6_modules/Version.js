export const version = '1.4.0';
//# sourceMappingURL=Version.js.map