export const version = '1.4.2';
//# sourceMappingURL=Version.js.map