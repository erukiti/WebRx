/// <reference path="Interfaces.d.ts" />
export declare var app: wx.IWebRxApp;
export declare var router: wx.IRouter;
export declare var messageBus: wx.IMessageBus;
