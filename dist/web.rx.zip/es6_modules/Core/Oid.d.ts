/**
* Returns the objects unique id or assigns it if unassigned
* @param {any} o
*/
export declare function getOid(o: any): string;
