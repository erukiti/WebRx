"use strict";
export const app = "app";
export const injector = "injector";
export const domManager = "domservice";
export const router = "router";
export const messageBus = "messageBus";
export const expressionCompiler = "expressioncompiler";
export const templateEngine = "templateEngine";
export const hasValueBindingValue = "has.bindings.value";
export const valueBindingValue = "bindings.value";
//# sourceMappingURL=Resources.js.map