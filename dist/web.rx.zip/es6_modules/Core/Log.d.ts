export declare var hintEnable: boolean;
export declare function critical(fmt: string, ...args: any[]): void;
export declare function error(fmt: string, ...args: any[]): void;
export declare function info(fmt: string, ...args: any[]): void;
export declare function hint(fmt: string, ...args: any[]): void;
